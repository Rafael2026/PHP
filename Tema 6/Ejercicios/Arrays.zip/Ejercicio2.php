<?php

  $datos = [

    [
      "nombre" => "Rafael",
      "apellidos" => "Aguilar Muñoz",
      "edad" => 19,
      "direccion" => "C/ Ceres, Nº 8",
      "telefono" => 609213851
    ],

    [
      "nombre" => "Pepe",
      "apellidos" => "Gómez Gorrón",
      "edad" => 22,
      "direccion" => "C/ Querpa, Nº 51",
      "telefono" => 111223344
    ],

    [
      "nombre" => "Ana",
      "apellidos" => "García Aume",
      "edad" => 17,
      "direccion" => "C/ Torre, Nº 14",
      "telefono" => 999887766
    ],

    [
      "nombre" => "Alejandro",
      "apellidos" => "Morco Zumi",
      "edad" => 25,
      "direccion" => "C/ Gema, Nº 22",
      "telefono" => 555446622
    ],

    [
      "nombre" => "Julia",
      "apellidos" => "Jiménez Lerca",
      "edad" => 15,
      "direccion" => "C/ Delta, Nº 30",
      "telefono" => 222663355
    ],
  ];
?>