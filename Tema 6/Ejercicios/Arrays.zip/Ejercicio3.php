<?php

  $datos = [77, 82, 54, 18, 2 => "Los Fratelli"];
  // 77, 82, Los Fratelli, 54, 18, 2
?>