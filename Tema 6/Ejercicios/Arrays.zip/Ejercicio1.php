<?php
  $datos = [
    [
      "nombre" => "Rafael",
      "apellidos" => "Aguilar Muñoz",
      "edad" => 19,
      "direccion" => "C/ Ceres, Nº 8",
      "telefono" => 609213851
    ],
  ];
?>