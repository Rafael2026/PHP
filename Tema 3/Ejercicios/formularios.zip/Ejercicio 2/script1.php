<?php

  "<form action='segundoScript.php' method='post'>
    lado: <input type='text' name='lado' required><br>
    radio: <input type='text' name='radio' required><br>
    <input type='submit'>
  </form>"

?>