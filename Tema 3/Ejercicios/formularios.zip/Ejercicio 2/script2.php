<?php

  $lado = $_POST["lado"];
  $radio = $_POST["radio"];

  echo ("<svg><rect width='$lado' height='$lado'/></svg>");

?>