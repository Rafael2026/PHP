<?php

  "<form action='segundoScript.php' method='post'>
    lado: <input type='text' name='lado' required><br>
    radio: <input type='text' name='radio' required><br>
    size: <input type='range' name='size' min='0' max='100'><br>
    color del borde: <input type='color' name='colorBorde'><br>
    color de la figura: <input type='color' name='colorFigura'>
    <input type='submit'>
  </form>"

?>