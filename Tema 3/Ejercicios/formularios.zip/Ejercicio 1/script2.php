<?php

  $name = $_POST["name"];
  $email = $_POST["email"];

  echo ("$name<br/>");
  echo ($email);

?>