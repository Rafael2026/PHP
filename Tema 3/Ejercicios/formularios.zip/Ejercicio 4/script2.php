<?php

  $V = $_POST["secuencia1"];
  $S = $_POST["secuencia2"];

  echo ("<svg><rect width='$lado' height='$lado' stroke='$colorBorde' stroke-width='$size' fill='$colorFigura'/></svg>");

?>