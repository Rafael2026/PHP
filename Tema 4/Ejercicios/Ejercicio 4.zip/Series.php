<?php

  $series = array(

    array("<h1>Lucifer</h1>", "<h2>Netflix</h2>", "<h2>85%</h2>", "<p>Lucifer (EL DIABLO) abandona el infierno y se traslada a Los Angeles y abre un lujoso bar nocturno llamado Lux.</p>"),

    array("<h1>Loki</h1>", "<h2>Disney+</h2>", "<h2>82%</h2>", "<p>El voluble villano Loki vuelve a ganarse el apodo de Dios del Engaño.</p>"),

    array("<h1>Luke Cage</h1>", "<h2>Netflix</h2>", "<h2>71%</h2>", "<p>Tras un experimento fallido, Luke Cage ha desarrollado una piel indestructible y una fuerza sobrehumana. Ahora es un fugitivo que intenta rehacer su vida en Harlem.</p>"),

    array("<h1>The Punisher</h1>", "<h2>Netflix</h2>", "<h2>81%</h2>", "<p>Un antiguo marine decidido a castigar a los asesinos de su familia termina atrapado en una conspiración militar.</p>"),

    array("<h1>Iron Fist</h1>", "<h2>Netflix</h2>", "<h2>66%</h2>", "<p>Danny Rand reaparece 15 años después de ser dado por muerto. Ahora, armado con un increíble poder, tratará de recuperar su pasado y cumplir su destino.</p>")
  );

?>